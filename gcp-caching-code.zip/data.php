<?php
header('Content-Type: application/json');
session_start(); // Start the session

error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'vendor/autoload.php';

use Google\Cloud\SecretManager\V1\SecretManagerServiceClient;
use Google\Cloud\SecretManager\V1\AccessSecretVersionRequest;

function fetchSecret(string $projectId, string $secretId, string $versionId)
{
    if ($projectId != '') {
        // Create the Secret Manager client.
        $client = new SecretManagerServiceClient();

        // Build the resource name of the secret version.
        $name = sprintf('projects/%s/secrets/%s/versions/%s', $projectId, $secretId, $versionId);

        // Access the secret version.
        $response = $client->accessSecretVersion($name);

        // Print the secret payload.
        //
        // WARNING: Do not print the secret in a production environment - this
        // snippet is showing how to access the secret material.
        $payload = $response->getPayload()->getData();
        return $payload;
    }
}

try {

    $operation = $_GET['operation'] ?? null;

    // Get GCP Project ID from file
    $gcp_project_id = '';
    $project_id_file = '/mnt/fs/gcpproject.txt';
    if (file_exists($project_id_file)) {
        $gcp_project_id = trim(file_get_contents($project_id_file));
    }

    if ($operation === 'setProductId') {
        $id = htmlentities($_GET['project_id']);
        $_SESSION['gcp_project_id'] = $id;
        echo json_encode(['error' => false]);
    } else if ($gcp_project_id != '') {
        $db_schema = 'prod_schema';
        $db_table = 'products';

        // Fetch DB configurations from secrets
        $db_url = fetchSecret($gcp_project_id, "db-hostname", "latest");
        $db_user = fetchSecret($gcp_project_id, "db-username", "latest");
        $db_pass = fetchSecret($gcp_project_id, "db-password", "latest");

        // Redis Connection details
        $redis_port = 6379; 
        $redis_host = fetchSecret($gcp_project_id, "redis-host", "latest");


        // Connect to Redis
        $redis = new Redis();
        $redis->connect($redis_host, $redis_port);
        if (!$redis->ping()) {
            die(json_encode(['error' => true, 'message' => 'Failed to connect to Redis']));
        }

        // Connect to MySQL
        $db_conn = mysqli_connect($db_url, $db_user, $db_pass, $db_schema);
        if (!$db_conn) {
            die(json_encode(['error' => true, 'message' => 'Database connection failed: ' . mysqli_connect_error()]));
        }

        // Determine the operation
        $action = $_GET['operation'] ?? null;

        if ($action === 'get_all_db') {
            $sql = 'SELECT * FROM ' . $db_table;
            $result = $db_conn->query($sql);
            $products = [];

            while ($row = mysqli_fetch_assoc($result)) {
                $products[] = $row;
            }

            echo json_encode(['error' => false, 'products' => $products, 'source' => 'DB']);

        } elseif ($action === 'get_all_cache') {
            $cache_keys = $redis->keys('*');

            if (empty($cache_keys)) {
                echo json_encode([
                    'error' => true,
                    'message' => 'No keys found in Redis.'
                ]);
                exit;
            }

            $products = $redis->mGet($cache_keys);

            if ($products === false) {
                echo json_encode([
                    'error' => true,
                    'message' => 'Failed to retrieve values from Redis.'
                ]);
                exit;
            }

            echo json_encode([
                'error' => false,
                'products' => array_map(
                    fn($product) => json_decode($product, true),
                    $products ?? [] // Ensure $products is an array
                ),
                'source' => 'Cache'
            ]);

        } elseif ($action === 'search') {
            $product_id = $_GET['product_id'] ?? null;
            if (!$product_id) {
                die(json_encode(['error' => true, 'message' => 'Product ID is required']));
            }

            $cache_key = 'PI' . $product_id;
            $cache_value = $redis->get($cache_key);

            if ($cache_value) {
                echo json_encode(['error' => false, 'product' => json_decode($cache_value, true), 'source' => 'Cache']);
            } else {
                $sql = 'SELECT * FROM ' . $db_table . ' WHERE id=' . intval($product_id);
                $result = $db_conn->query($sql);

                if ($result && $result->num_rows > 0) {
                    $product = mysqli_fetch_assoc($result);
                    $redis->set($cache_key, json_encode($product));
                    echo json_encode(['error' => false, 'product' => $product, 'source' => 'DB']);
                } else {
                    echo json_encode(['error' => true, 'message' => 'Product not found']);
                }
            }

        } elseif ($action === 'add') {
            $name = $_GET['product_name'] ?? null;
            $quantity = $_GET['product_quantity'] ?? null;
            $price = $_GET['product_price'] ?? null;

            if (!$name || !$quantity || !$price) {
                die(json_encode(['error' => true, 'message' => 'Missing parameters']));
            }

            $sql = "INSERT INTO $db_table (name, quantity, price) VALUES ('$name', '$quantity', '$price')";
            if ($db_conn->query($sql)) {
                echo json_encode(['error' => false, 'message' => 'Product added successfully']);
            } else {
                echo json_encode(['error' => true, 'message' => mysqli_error($db_conn)]);
            }

        } elseif ($action === 'update') {
            $id = $_GET['product_id'] ?? null;
            $name = $_GET['product_name'] ?? null;
            $quantity = $_GET['product_quantity'] ?? null;
            $price = $_GET['product_price'] ?? null;

            if (!$id || !$name || !$quantity || !$price) {
                die(json_encode(['error' => true, 'message' => 'Missing parameters']));
            }

            $sql = "UPDATE $db_table SET name='$name', quantity='$quantity', price='$price' WHERE id='$id'";
            if ($db_conn->query($sql)) {
                $redis->del('PI' . $id);
                echo json_encode(['error' => false, 'message' => 'Product updated successfully']);
            } else {
                echo json_encode(['error' => true, 'message' => mysqli_error($db_conn)]);
            }

        } elseif ($action === 'delete') {
            $id = $_GET['product_id'] ?? null;

            if (!$id) {
                die(json_encode(['error' => true, 'message' => 'Product ID is required']));
            }

            $sql = "DELETE FROM $db_table WHERE id='$id'";
            if ($db_conn->query($sql)) {
                $redis->del('PI' . $id);
                echo json_encode(['error' => false, 'message' => 'Product deleted successfully']);
            } else {
                echo json_encode(['error' => true, 'message' => mysqli_error($db_conn)]);
            }

        } else if ($action === 'add_from_file') {
            $file = fopen($_GET['file_path'], 'r');

            // Updated fgetcsv with explicit escape parameter
            while ($line = fgetcsv($file, 1000, ",", '"', "\\")) {
                $sql = 'INSERT INTO ' . $db_table . ' (name, quantity, price) 
                        VALUES ("' . htmlentities($line[0]) . '", "' . htmlentities($line[1]) . '", "' . htmlentities($line[2]) . '")';
                $db_conn->query($sql);
            }

            fclose($file); // Close file after reading

            echo (json_encode([
                'error' => false,
                'message' => 'Data added successfully'
            ]));
        } else {
            echo json_encode(['error' => true, 'message' => 'Invalid operation']);
        }

        mysqli_close($db_conn);
    }

} catch (Exception $e) {
    echo json_encode(['error' => true, 'message' => $e->getMessage()]);
}
