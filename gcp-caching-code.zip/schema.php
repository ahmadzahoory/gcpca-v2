<?php
// Load the GCP SDK
require 'vendor/autoload.php';

use Google\Cloud\SecretManager\V1\SecretManagerServiceClient;

// Fetch secrets from GCP Secret Manager
function getSecret($secretName) {
    $client = new SecretManagerServiceClient();
    $name = $client->secretVersionName('gcp-new-444210', $secretName, 'latest');
    $response = $client->accessSecretVersion($name);
    return $response->getPayload()->getData();
}

// Retrieve database secrets
$dbhostname = getSecret('db-hostname');
$username = getSecret('db-username');
$password = getSecret('db-password');
$dbname = "prod_schema";

// Checking connection
$conn = new mysqli($dbhostname, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table and insert data
$sql = "CREATE TABLE `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `price` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_unique` (`id`)
)";
if ($conn->query($sql) === TRUE) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . $sql . "</br>" . $conn->error;
}

// Insert records
$records = [
    ['Keyboard', '17', '1800'],
    ['Monitor', '11', '7900'],
    ['Mouse', '38', '490'],
    ['Headphone', '28', '1400'],
    ['USB Cable', '70', '430']
];
foreach ($records as $record) {
    $sql = "INSERT INTO products (name, quantity, price) VALUES ('$record[0]', '$record[1]', '$record[2]')";
    if ($conn->query($sql) === TRUE) {
        echo "$record[0] added successfully</br>";
    } else {
        echo "Error adding $record[0]: " . $sql . "</br>" . $conn->error;
    }
}

$conn->close();
?>
