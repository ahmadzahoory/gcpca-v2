<?php
// Load the GCP SDK
require 'vendor/autoload.php';

use Google\Cloud\SecretManager\V1\SecretManagerServiceClient;
use Google\Cloud\SecretManager\V1\AccessSecretVersionRequest;

// Get GCP Project ID from file
$project_id_file = '/mnt/efs/gcpproject.txt';
$project_id = '';
if (file_exists($project_id_file)) {
    $project_id = trim(file_get_contents($project_id_file));
}

if (empty($project_id)) {
    die("Error: GCP Project ID not found in $project_id_file");
}

// Fetch secrets from GCP Secret Manager
function getSecret($projectId, $secretName)
{
    $client = new SecretManagerServiceClient();
    $name = sprintf('projects/%s/secrets/%s/versions/latest', $projectId, $secretName);
    $response = $client->accessSecretVersion($name);
    return $response->getPayload()->getData();
}

$dbname = "prod_schema";

// Retrieve database secrets
$dbhostname = getSecret($project_id, 'db-hostname');
$username = getSecret($project_id, 'db-username');
$password = getSecret($project_id, 'db-password');

// First connect without specifying a database to create it if it doesn't exist
$conn = new mysqli($dbhostname, $username, $password);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS `$dbname`";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully or already exists<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select the database
$conn->select_db($dbname);

// Create table and insert data
$sql = "CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `price` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_unique` (`id`)
)";
if ($conn->query($sql) === TRUE) {
    echo "Table products created successfully";
} else {
    echo "Error creating table: " . $sql . "</br>" . $conn->error;
}

// Insert records
$records = [
    ['Keyboard', '17', '1800'],
    ['Monitor', '11', '7900']
];
foreach ($records as $record) {
    $sql = "INSERT INTO products (name, quantity, price) VALUES ('$record[0]', '$record[1]', '$record[2]')";
    if ($conn->query($sql) === TRUE) {
        echo "$record[0] added successfully</br>";
    } else {
        echo "Error adding $record[0]: " . $sql . "</br>" . $conn->error;
    }
}

$conn->close();
?>
