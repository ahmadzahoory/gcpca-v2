const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const https = require('https');
require('@google-cloud/trace-agent').start();

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json()); // Add this line

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Function to get external LoadBalancer IPs dynamically
async function getServiceExternalIPs() {
  try {
    const namespace = process.env.NAMESPACE || 'media-app';
    const serviceAccountToken = fs.readFileSync('/var/run/secrets/kubernetes.io/serviceaccount/token', 'utf8');
    const kubernetesApiUrl = `https://kubernetes.default.svc.cluster.local/api/v1/namespaces/${namespace}/services`;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'kubernetes.default.svc.cluster.local',
        port: 443,
        path: `/api/v1/namespaces/${namespace}/services`,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${serviceAccountToken}`,
          'Accept': 'application/json'
        },
        rejectUnauthorized: false
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const services = JSON.parse(data);
            const serviceIPs = {};

            services.items?.forEach(service => {
              if (service.spec.type === 'LoadBalancer' && service.status.loadBalancer?.ingress?.[0]?.ip) {
                serviceIPs[service.metadata.name] = service.status.loadBalancer.ingress[0].ip;
              }
            });

            resolve(serviceIPs);
          } catch (error) {
            console.error('Error parsing Kubernetes API response:', error);
            resolve({});
          }
        });
      });

      req.on('error', (error) => {
        console.error('Error querying Kubernetes API:', error);
        resolve({});
      });

      req.end();
    });
  } catch (error) {
    console.error('Error reading service account token:', error);
    return {};
  }
}


// Load credentials from K8s Secrets (mounted as files)
const username = fs.readFileSync('/etc/secrets/username', 'utf8').trim();
const password = fs.readFileSync('/etc/secrets/password', 'utf8').trim();

// Get Container IP
const containerIP = os.networkInterfaces()['eth0'][0].address;

// Login Page
app.get('/', (req, res) => {
  res.send(`
    <h2>Media App - Login</h2>
    <form action="/login" method="POST">
      <input name="username" placeholder="Username" required/><br/><br/>
      <input name="password" placeholder="Password" type="password" required/><br/><br/>
      <button type="submit">Login</button>
    </form>
    <p>Container IP: ${containerIP}</p>
  `);
});

// Login Validation
app.post('/login', async (req, res) => {
  console.log("inside login")
  const { username: inputUser, password: inputPass } = req.body;
  if (inputUser === username && inputPass === password) {
    // Get service URLs from environment variables (preferred) or use dynamic discovery
    let imageServiceUrl = process.env.IMAGE_SERVICE_URL;
    let videoServiceUrl = process.env.VIDEO_SERVICE_URL;

    if (!imageServiceUrl || !videoServiceUrl) {
      console.log('Environment variables not set, attempting dynamic discovery...');
      const serviceIPs = await getServiceExternalIPs();
      console.log('Retrieved service IPs:', serviceIPs);

      // Use external IPs if available, fallback to internal service names
      imageServiceUrl = serviceIPs['image-app-loadbalancer'] ?
        `http://${serviceIPs['image-app-loadbalancer']}` :
        'http://image-service.media-app.svc.cluster.local';

      videoServiceUrl = serviceIPs['video-app-loadbalancer'] ?
        `http://${serviceIPs['video-app-loadbalancer']}` :
        'http://video-service.media-app.svc.cluster.local';
    }

    console.log(`Using Image Service URL: ${imageServiceUrl}`);
    console.log(`Using Video Service URL: ${videoServiceUrl}`);

    res.send(`
      <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
        .nav-button {
          display: inline-block; 
          margin: 10px; 
          padding: 10px 20px; 
          color: white; 
          text-decoration: none; 
          border-radius: 5px;
          cursor: pointer;
          border: none;
          font-size: 16px;
        }
        .nav-button:hover { opacity: 0.8; }
        .image-btn { background: #007cba; }
        .video-btn { background: #28a745; }
      </style>
      <script>
        function navigateToService(url) {
          console.log('Navigating to:', url);
          window.location.href = url;
        }
      </script>
      <h2>Welcome, ${inputUser}!</h2>
      <div style="margin: 20px 0;">
        <button class="nav-button image-btn" onclick="navigateToService('${imageServiceUrl}')">
           Go to Image Service
        </button><br/>
        <button class="nav-button video-btn" onclick="navigateToService('${videoServiceUrl}')">
           Go to Video Service
        </button>
      </div>
      <p>Container IP: ${containerIP}</p>
      <p><small>Image Service: ${imageServiceUrl}</small></p>
      <p><small>Video Service: ${videoServiceUrl}</small></p>
      <p><small>Shared Storage: /shared (Filestore mounted)</small></p>
    `);
  } else {
    res.send('<h2>Login Failed</h2><a href="/">Try Again</a>');
  }
});

// Selection page route (for back button navigation)
app.get('/select', async (req, res) => {
  // Get service URLs from environment variables (preferred) or use dynamic discovery
  let imageServiceUrl = process.env.IMAGE_SERVICE_URL;
  let videoServiceUrl = process.env.VIDEO_SERVICE_URL;

  if (!imageServiceUrl || !videoServiceUrl) {
    console.log('Environment variables not set, attempting dynamic discovery...');
    const serviceIPs = await getServiceExternalIPs();
    console.log('Retrieved service IPs:', serviceIPs);

    // Use external IPs if available, fallback to internal service names
    imageServiceUrl = serviceIPs['image-app-loadbalancer'] ?
      `http://${serviceIPs['image-app-loadbalancer']}` :
      'http://image-service.media-app.svc.cluster.local';

    videoServiceUrl = serviceIPs['video-app-loadbalancer'] ?
      `http://${serviceIPs['video-app-loadbalancer']}` :
      'http://video-service.media-app.svc.cluster.local';
  }

  console.log(`Using Image Service URL: ${imageServiceUrl}`);
  console.log(`Using Video Service URL: ${videoServiceUrl}`);

  res.send(`
    <style>
      body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
      .nav-button {
        display: inline-block; 
        margin: 10px; 
        padding: 10px 20px; 
        color: white; 
        text-decoration: none; 
        border-radius: 5px;
        cursor: pointer;
        border: none;
        font-size: 16px;
      }
      .nav-button:hover { opacity: 0.8; }
      .image-btn { background: #007cba; }
      .video-btn { background: #28a745; }
      .home-btn { background: #6c757d; margin-top: 20px; }
    </style>
    <script>
      function navigateToService(url) {
        console.log('Navigating to:', url);
        window.location.href = url;
      }
    </script>
    <h2>Media App - Select Service</h2>
    <div style="margin: 20px 0;">
      <button class="nav-button image-btn" onclick="navigateToService('${imageServiceUrl}')">
         Go to Image Service
      </button><br/>
      <button class="nav-button video-btn" onclick="navigateToService('${videoServiceUrl}')">
         Go to Video Service
      </button>
    </div>
    <div style="margin-top: 30px;">
      <a href="/" class="nav-button home-btn">← Back to Login</a>
    </div>
    <p>Container IP: ${containerIP}</p>
    <p><small>Image Service: ${imageServiceUrl}</small></p>
    <p><small>Video Service: ${videoServiceUrl}</small></p>
    <p><small>Shared Storage: /shared (Filestore mounted)</small></p>
  `);
});

// Test Filestore endpoint
app.get('/filestore-test', (req, res) => {
  try {
    const testFile = '/shared/test.txt';
    const timestamp = new Date().toISOString();
    fs.writeFileSync(testFile, `Test written at ${timestamp} from container ${containerIP}\n`, { flag: 'a' });
    const content = fs.readFileSync(testFile, 'utf8');

    res.send(`
      <h2>Filestore Test</h2>
      <p>Successfully wrote to shared storage!</p>
      <h3>Content of /shared/test.txt:</h3>
      <pre>${content}</pre>
      <a href="/">Back to Home</a>
    `);
  } catch (err) {
    res.status(500).send(`Error testing Filestore: ${err.message}`);
  }
});

app.listen(3000, () => console.log('Front App running on port 3000'));
