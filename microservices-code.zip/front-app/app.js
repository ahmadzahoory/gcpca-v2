const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const https = require('https');
require('@google-cloud/trace-agent').start();

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Function to get external LoadBalancer IPs dynamically
async function getServiceExternalIPs() {
  try {
    const namespace = process.env.NAMESPACE || 'media-app';
    const serviceAccountToken = fs.readFileSync('/var/run/secrets/kubernetes.io/serviceaccount/token', 'utf8');
    const kubernetesApiUrl = `https://kubernetes.default.svc.cluster.local/api/v1/namespaces/${namespace}/services`;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'kubernetes.default.svc.cluster.local',
        port: 443,
        path: `/api/v1/namespaces/${namespace}/services`,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${serviceAccountToken}`,
          'Accept': 'application/json'
        },
        rejectUnauthorized: false
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          try {
            const services = JSON.parse(data);
            const serviceIPs = {};

            services.items?.forEach(service => {
              if (service.spec.type === 'LoadBalancer' && service.status.loadBalancer?.ingress?.[0]?.ip) {
                serviceIPs[service.metadata.name] = service.status.loadBalancer.ingress[0].ip;
              }
            });

            resolve(serviceIPs);
          } catch (error) {
            console.error('Error parsing Kubernetes API response:', error);
            resolve({});
          }
        });
      });

      req.on('error', (error) => {
        console.error('Error querying Kubernetes API:', error);
        resolve({});
      });

      req.end();
    });
  } catch (error) {
    console.error('Error reading service account token:', error);
    return {};
  }
}

// Load credentials
const username = fs.readFileSync('/etc/secrets/username', 'utf8').trim();
const password = fs.readFileSync('/etc/secrets/password', 'utf8').trim();

// Get Container IP
const containerIP = os.networkInterfaces()['eth0'][0].address;

// Helper to check authentication from cookies
const isAuthenticated = (req) => {
  const cookies = req.headers.cookie || '';
  return cookies.includes('authenticated=true');
};

// --- ROUTES ---

// Main Page (Home)
app.get('/', (req, res) => {
  if (!isAuthenticated(req)) {
    return res.redirect('/login');
  }
  res.redirect('/select');
});

// Login Page
app.get('/login', (req, res) => {
  if (isAuthenticated(req)) {
    return res.redirect('/select');
  }
  res.send(`
    <html>
    <head>
      <title>Media App - Login</title>
      <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
        .login-box { display: inline-block; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        input { margin: 10px; padding: 8px; width: 200px; }
        button { padding: 10px 20px; background: #007cba; color: white; border: none; border-radius: 5px; cursor: pointer; }
      </style>
    </head>
    <body>
      <div class="login-box">
        <h2>Media App Login</h2>
        <form action="/login" method="POST">
          <input name="username" placeholder="Username" required/><br/>
          <input name="password" placeholder="Password" type="password" required/><br/>
          <button type="submit">Login</button>
        </form>
      </div>
      <p>Container IP: ${containerIP}</p>
    </body>
    </html>
  `);
});

// Login POST
app.post('/login', (req, res) => {
  const { username: inputUser, password: inputPass } = req.body;
  if (inputUser === username && inputPass === password) {
    res.setHeader('Set-Cookie', 'authenticated=true; Path=/; HttpOnly');
    res.redirect('/select');
  } else {
    res.send('<h2>Login Failed</h2><a href="/login">Try Again</a>');
  }
});

// Selection Page
app.get('/select', async (req, res) => {
  if (!isAuthenticated(req)) {
    return res.redirect('/login');
  }

  let imageServiceUrl = process.env.IMAGE_SERVICE_URL;
  let videoServiceUrl = process.env.VIDEO_SERVICE_URL;

  if (!imageServiceUrl || !videoServiceUrl) {
    const serviceIPs = await getServiceExternalIPs();
    imageServiceUrl = serviceIPs['image-app-loadbalancer'] ? `http://${serviceIPs['image-app-loadbalancer']}` : 'http://image-service.media-app.svc.cluster.local';
    videoServiceUrl = serviceIPs['video-app-loadbalancer'] ? `http://${serviceIPs['video-app-loadbalancer']}` : 'http://video-service.media-app.svc.cluster.local';
  }

  res.send(`
    <html>
    <head>
      <title>Media App - Selection</title>
      <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
        .nav-button {
          display: inline-block; 
          margin: 10px; 
          padding: 10px 20px; 
          color: white; 
          text-decoration: none; 
          border-radius: 5px;
          cursor: pointer;
          border: none;
          font-size: 16px;
        }
        .image-btn { background: #007cba; }
        .video-btn { background: #28a745; }
        .logout-btn { background: #6c757d; margin-top: 20px; }
      </style>
      <script>
        function navigateToService(url) {
          window.location.href = url;
        }
      </script>
    </head>
    <body>
      <h2>Welcome to Media App!</h2>
      <div style="margin: 20px 0;">
        <button class="nav-button image-btn" onclick="navigateToService('${imageServiceUrl}')">Go to Image Service</button><br/>
        <button class="nav-button video-btn" onclick="navigateToService('${videoServiceUrl}')">Go to Video Service</button>
      </div>
      <div style="margin-top: 30px;">
        <a href="/logout" class="nav-button logout-btn">← Logout</a>
      </div>
      <p>Container IP: ${containerIP}</p>
    </body>
    </html>
  `);
});

// Logout
app.get('/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'authenticated=false; Path=/; Max-Age=0');
  res.redirect('/login');
});

// Test Filestore
app.get('/filestore-test', (req, res) => {
  try {
    const testFile = '/shared/test.txt';
    fs.writeFileSync(testFile, `Test from ${containerIP} at ${new Date().toISOString()}\n`, { flag: 'a' });
    const content = fs.readFileSync(testFile, 'utf8');
    res.send(`<h2>Filestore</h2><pre>${content}</pre><a href="/">Back</a>`);
  } catch (err) { res.status(500).send(err.message); }
});

app.listen(3000, () => console.log('Front App running on port 3000'));
