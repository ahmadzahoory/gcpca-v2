const express = require('express');
const multer = require('multer');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const os = require('os');

const CONFIG_FILE = '/shared/image_bucket.txt';

const getBucketName = () => {
    try {
        if (fs.existsSync(CONFIG_FILE)) {
            return fs.readFileSync(CONFIG_FILE, 'utf8').trim();
        }
    } catch (err) {
        console.error('Error reading bucket config:', err);
    }
    return process.env.BUCKET_NAME || 'static-content-gks';
};

const app = express();
const containerIP = os.networkInterfaces()['eth0'][0].address;

require('@google-cloud/trace-agent').start();

// Initialize GCS
const storage = new Storage();
// Initial bucket name, will be updated dynamically in routes
let BUCKET_NAME = getBucketName();

// Multer setup for memory storage (no local saving)
const upload = multer({ storage: multer.memoryStorage() });

// Middleware to handle JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API endpoint to change bucket dynamically
app.post('/api/change-bucket', (req, res) => {
    const { bucketName } = req.body;
    if (!bucketName) {
        return res.status(400).json({ error: 'Bucket name is required' });
    }

    try {
        fs.writeFileSync(CONFIG_FILE, bucketName);
        BUCKET_NAME = bucketName;
        console.log(`Bucket changed and persisted to: ${BUCKET_NAME}`);
        res.json({ message: `Bucket changed to ${BUCKET_NAME}` });
    } catch (err) {
        console.error('Error persisting bucket change:', err);
        res.status(500).json({ error: 'Failed to persist bucket change' });
    }
});

// Upload Page
app.get('/', async (req, res) => {
    try {
        BUCKET_NAME = getBucketName(); // Refresh from shared config
        // List files from GCS
        let files = [];
        try {
            const currentBucket = storage.bucket(BUCKET_NAME);
            [files] = await currentBucket.getFiles();
        } catch (error) {
            console.error('Error accessing GCS bucket:', error);
            // Return specific error if bucket is missing or inaccessible
            return res.send(`
                <html>
                <head>
                    <title>Service Unavailable</title>
                    <style>
                        body { font-family: Arial, sans-serif; text-align: center; margin: 50px; }
                        .error-box { background: #fee; border: 1px solid #c00; padding: 20px; border-radius: 5px; display: inline-block; }
                        h2 { color: #c00; }
                    </style>
                </head>
                <body>
                    <div class="error-box">
                        <h2>⚠️ Storage Service Unavailable</h2>
                        <p>The image storage bucket (${BUCKET_NAME}) is not accessible.</p>
                        <p>Please contact the system administrator to verify cloud storage configuration.</p>
                        <a href="${process.env.MAIN_APP_URL}/select" style="display:inline-block; margin-top:15px;">Back to Selection</a>
                    </div>
                </body>
                </html>
            `);
        }

        const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'];
        // Generate signed URLs (V4) for each image so private buckets can be used without public ACLs
        const signedUrls = await Promise.all(files
            .filter(file => imageExtensions.some(ext => file.name.toLowerCase().endsWith(ext)))
            .map(async (file) => {

                try {
                    const options = {
                        version: 'v4',
                        action: 'read',
                        expires: Date.now() + 15 * 60 * 1000, // 15 minutes
                    };
                    const [url] = await storage.bucket(BUCKET_NAME).file(file.name).getSignedUrl(options);
                    return `<div class="image-item"><img src="${url}" alt="Uploaded Image"></div>`;
                } catch (err) {
                    console.error('Error generating signed URL for', file.name, err);
                    // Fallback to object name (will 403 if not publicly accessible)
                    const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${encodeURIComponent(file.name)}`;
                    return `<div class="image-item"><img src="${publicUrl}" alt="Uploaded Image"></div>`;
                }
            })
        );

        const images = signedUrls.join('');

        res.send(`
        <html>
        <head>
            <title>Image Uploads</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin: 20px;
                }
                .container {
                    max-width: 800px;
                    margin: auto;
                }
                form {
                    margin-bottom: 20px;
                }
                .bucket-config {
                    background: #f5f5f5;
                    padding: 15px;
                    margin-bottom: 20px;
                    border-radius: 5px;
                }
                .back-button {
                    background: #6c757d;
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    text-decoration: none;
                    display: inline-block;
                    margin-bottom: 20px;
                }
                .back-button:hover {
                    background: #5a6268;
                }
                .image-grid {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    justify-content: center;
                }
                .image-item {
                    border: 1px solid #ddd;
                    padding: 10px;
                    border-radius: 8px;
                    background: #fff;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                }
                .image-item img {
                    width: 200px;
                    height: auto;
                    display: block;
                    border-radius: 5px;
                }
            </style>
            <script>
                function changeBucket() {
                    const bucketName = document.getElementById('bucketName').value;
                    fetch('/images/api/change-bucket', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ bucketName })
                    })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message || data.error);
                        if (!data.error) location.reload();
                    });
                }
            </script>
        </head>
        <body>
            <div class="container">
                <a href="${process.env.MAIN_APP_URL}/select" class="back-button">← Back to Selection</a>
                <h2>Image Upload Service</h2>
                
                <div class="bucket-config">
                    <h3>GCP Bucket Configuration</h3>
                    <p>Current Bucket: <strong>${BUCKET_NAME}</strong></p>
                    <input type="text" id="bucketName" placeholder="Enter new bucket name" />
                    <button onclick="changeBucket()">Change Bucket</button>
                </div>
                
                <form action="/images/upload" method="POST" enctype="multipart/form-data">
                    <input type="file" name="image" accept="image/*" required/><br/><br/>
                    <button type="submit">Upload Image</button>
                </form>
                
                <h3>Stored Images:</h3>
                <div class="image-grid">
                    ${images}
                </div>
                <p>Container IP: ${containerIP}</p>
            </div>
        </body>
        </html>
    `);
    } catch (err) {
        console.error('Error fetching images from GCS:', err);
        res.status(500).send('Error loading images');
    }
});

// Handle Upload and Push to GCS
app.post('/upload', upload.single('image'), async (req, res) => {
    BUCKET_NAME = getBucketName(); // Ensure we use the latest bucket
    console.log("inside upload using bucket:", BUCKET_NAME);
    if (!req.file) {
        return res.status(400).send('No file uploaded.');
    }

    const currentBucket = storage.bucket(BUCKET_NAME);
    const blob = currentBucket.file(Date.now() + '-' + req.file.originalname);
    const blobStream = blob.createWriteStream({
        resumable: false,
        metadata: {
            contentType: req.file.mimetype,
        },
    });

    blobStream.on('error', err => {
        console.error('Upload Error:', err);
        res.status(500).send('Error uploading file');
    });

    blobStream.on('finish', () => {
        const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${blob.name}`;
        console.log(`Uploaded to: ${publicUrl}`);
        res.redirect('/images/');
    });

    blobStream.end(req.file.buffer);
});

// Health Check Endpoint
app.get('/health', (req, res) => res.send('OK'));

app.listen(3001, () => console.log('Image App running on port 3001'));
