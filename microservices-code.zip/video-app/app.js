const express = require('express');
const multer = require('multer');
const { Storage } = require('@google-cloud/storage');
const path = require('path');
const os = require('os');

const app = express();
const containerIP = os.networkInterfaces()['eth0'][0].address;
require('@google-cloud/trace-agent').start();

// Initialize GCS
const storage = new Storage();
let BUCKET_NAME = process.env.BUCKET_NAME || 'static-content-gks'; // Allow dynamic bucket naming

// Multer setup for memory storage (no local saving)
const upload = multer({ storage: multer.memoryStorage() });

// Middleware to handle JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '500mb' }));  // Increase limit for JSON payload
app.use(express.urlencoded({ limit: '500mb', extended: true }));  // Increase limit for URL-encoded data

// API endpoint to change bucket dynamically
app.post('/api/change-bucket', (req, res) => {
  const { bucketName } = req.body;
  if (!bucketName) {
    return res.status(400).json({ error: 'Bucket name is required' });
  }

  BUCKET_NAME = bucketName;
  console.log(`Bucket changed to: ${BUCKET_NAME}`);
  res.json({ message: `Bucket changed to ${BUCKET_NAME}` });
});

// Upload Page
app.get('/', async (req, res) => {
  try {
    // List files from GCS
    const currentBucket = storage.bucket(BUCKET_NAME);
    const [files] = await currentBucket.getFiles();
    // Filter only video files based on common extensions
    const videoExtensions = ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv', '.webm'];
    // Generate signed V4 URLs for videos so private buckets can be used without public ACLs
    const signedVideoUrls = await Promise.all(files
      .filter(file => videoExtensions.some(ext => file.name.toLowerCase().endsWith(ext)))
      .map(async (file) => {
        try {
          const options = {
            version: 'v4',
            action: 'read',
            expires: Date.now() + 15 * 60 * 1000, // 15 minutes
          };
          const [url] = await storage.bucket(BUCKET_NAME).file(file.name).getSignedUrl(options);
          return `<div class="video-item">
                    <video controls>
                        <source src="${url}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>`;
        } catch (err) {
          console.error('Error generating signed URL for', file.name, err);
          const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${encodeURIComponent(file.name)}`;
          return `<div class="video-item">
                    <video controls>
                        <source src="${publicUrl}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                </div>`;
        }
      })
    );

    const videos = signedVideoUrls.join('');

    res.send(`
        <html>
        <head>
            <title>Video Uploads</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin: 20px;
                }
                .container {
                    max-width: 800px;
                    margin: auto;
                }
                form {
                    margin-bottom: 20px;
                }
                .bucket-config {
                    background: #f5f5f5;
                    padding: 15px;
                    margin-bottom: 20px;
                    border-radius: 5px;
                }
                .back-button {
                    background: #6c757d;
                    color: white;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    text-decoration: none;
                    display: inline-block;
                    margin-bottom: 20px;
                }
                .back-button:hover {
                    background: #5a6268;
                }
                .video-grid {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 15px;
                    justify-content: center;
                }
                .video-item {
                    border: 1px solid #ddd;
                    padding: 10px;
                    border-radius: 8px;
                    background: #fff;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                }
                .video-item video {
                    width: 320px;
                    height: 240px;
                    display: block;
                    border-radius: 5px;
                }
            </style>
            <script>
                function changeBucket() {
                    const bucketName = document.getElementById('bucketName').value;
                    fetch('/api/change-bucket', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ bucketName })
                    })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message || data.error);
                        if (!data.error) location.reload();
                    });
                }
            </script>
        </head>
        <body>
            <div class="container">
                <a href="${process.env.MAIN_APP_URL || 'http://MAIN_APP_EXTERNAL_IP/select'}" class="back-button">← Back to Home</a>
                <h2>Video Upload Service</h2>
                
                <div class="bucket-config">
                    <h3>GCP Bucket Configuration</h3>
                    <p>Current Bucket: <strong>${BUCKET_NAME}</strong></p>
                    <input type="text" id="bucketName" placeholder="Enter new bucket name" />
                    <button onclick="changeBucket()">Change Bucket</button>
                </div>
                
                <form action="/upload" method="POST" enctype="multipart/form-data">
                    <input type="file" name="video" accept="video/*" required/><br/><br/>
                    <button type="submit">Upload Video</button>
                </form>
                
                <h3>Stored Videos:</h3>
                <div class="video-grid">
                    ${videos}
                </div>
                <p>Container IP: ${containerIP}</p>
            </div>
        </body>
        </html>
    `);
  } catch (err) {
    console.error('Error fetching videos from GCS:', err);
    res.status(500).send('Error loading videos');
  }
});

// Handle Upload and Push to GCS
app.post('/upload', upload.single('video'), async (req, res) => {
  console.log("inside upload");
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  const currentBucket = storage.bucket(BUCKET_NAME);
  const blob = currentBucket.file(Date.now() + '-' + req.file.originalname);
  const blobStream = blob.createWriteStream({
    resumable: false,
    metadata: {
      contentType: req.file.mimetype,
    },
  });

  blobStream.on('error', err => {
    console.error('Upload Error:', err);
    res.status(500).send('Error uploading file');
  });

  blobStream.on('finish', () => {
    const publicUrl = `https://storage.googleapis.com/${BUCKET_NAME}/${blob.name}`;
    console.log(`Uploaded to: ${publicUrl}`);
    res.redirect('/');
  });

  blobStream.end(req.file.buffer);
});

// Health Check Endpoint
app.get('/health', (req, res) => res.send('OK'));

app.listen(3002, () => console.log('Video App running on port 3002'));
