<!DOCTYPE html>
<html>
<head>
    <title>Ahmad</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
    <style>
        .center { text-align: center !important; }
    </style>
</head>
<body style="background-color: #af7ac5">
    <div class="ui container">
        <div class="ui segment" style="max-width: 800px; margin: auto;">
            <h2 class="ui header center"><font color="purple">GCP Scalable Lab</font></h2>
            <h5 class="ui header center"><font color="blue">Server IP Address <?= $_SERVER['SERVER_ADDR'] ?></font></h5>
            <form class="ui form" style="width: 400px; margin: auto;">
                <div class="field">
                    <label>Product name</label>
                    <input type="text" id="new_product_name" placeholder="Product name" required>
                </div>
                <div class="field">
                    <label>Product quantity</label>
                    <input type="number" id="new_product_quantity" placeholder="Product quantity" required>
                </div>
                <div class="field">
                    <label>Product price</label>
                    <input type="number" id="new_product_price" placeholder="Product price" required>
                </div>
                <button class="ui button" type="button" id="product_add">Add</button>
                <button class="ui button" type="button" id="product_fetch" onclick="fetchProducts()">Read</button>
            </form>
            <table class="ui celled table">
                <thead>
                    <tr>
                        <th class="center">ID</th>
                        <th class="center">Name</th>
                        <th class="center">Quantity</th>
                        <th class="center">Price</th>
						<th></th>
						<th></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    let project_id = '';
    let read_secret = '';
    let write_secret = '';

    $('.setting').click(() => {
        project_id = prompt('Enter GCP Project ID');
        setProductId();
    });

    function setProductId() {
        $.ajax({
            url: `data.php?operation=setProductId&project_id=${project_id}`,
            success: (res) => {
                if (res.error) {
                    alert(res.message);
                    return;
                }
                else{
                    alert("project id set sucessfully.")
                }
            },
            error: (err) => alert(err.message)
        });
    }

    function fetchProducts() {
        $.ajax({
            url: `data.php?operation=get`,
            success: (res) => {
                if (res.error) {
                    alert(res.message);
                    return;
                }
                $('tbody').html(res.products.map(product => `
					<tr data-id="${product.id}" data-name="${product.name}" data-quantity="${product.quantity}" data-price="${product.price}"> 
						<td>${product.id}</td>
                        <td>${product.name}</td>
                        <td>${product.quantity}</td>
                        <td>${product.price}</td>
						<td class="center"><i class="edit green icon"></i></td>
						<td class="center"><i class="trash alternate red icon"></i></td>
                    </tr>
                `).join(''));
            },
            error: (err) => alert(err.message)
        });
    }

    $('#product_add').click((e) => {
        e.preventDefault();
        $.ajax({
            url: `data.php?operation=add&product_name=${$('#new_product_name').val()}&product_quantity=${$('#new_product_quantity').val()}&product_price=${$('#new_product_price').val()}`,
            success: fetchProducts,
            error: (err) => alert(err.message)
        });
    });


	//update
	$(document).on('click', '.edit.icon', function() {
		let tr = $(this).closest('tr')[0];
		let product_id = $(tr).data('id'),
			product_name = undefined,
			product_quantity = undefined,
			product_price = undefined;

		while (!product_name || product_name.length === 0)
			product_name = prompt('Product name');

		while (!product_quantity || isNaN(product_quantity))
			product_quantity = prompt('Product quantity');

		while (!product_price || isNaN(product_price))
			product_price = prompt('Product price');

		$.ajax({
			url: `data.php?operation=update&product_id=${product_id}&product_name=${product_name}&product_quantity=${product_quantity}&product_price=${product_price}`,
			success: res => {
				if (res.error) {
					alert(res.message);
					return;
				}
				fetchProducts();
			},
			error: err => {
				console.log(err);
				alert(err.message);
			}
		});
	});

	// delete
	$(document).on('click', '.trash.icon', function() {
		let tr = $(this).closest('tr')[0]
		let product_id = $(tr).data('id')

		$.ajax({
			url: `data.php?operation=delete&product_id=${product_id}`,
			success: res => {
				if (res.error) {
					alert(res.message);
					return;
				}	
				fetchProducts();
			},
			error: err => {
				console.log(err);
				alert(err.message);
			}
		});
	});
</script>
</body>
</html>
