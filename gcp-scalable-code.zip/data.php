<?php
header('Content-Type: application/json');
session_start(); // Start the session

require_once 'vendor/autoload.php';
use Google\Cloud\SecretManager\V1\Client\SecretManagerServiceClient;
use Google\Cloud\SecretManager\V1\GetSecretRequest;
use Google\Cloud\SecretManager\V1\AccessSecretVersionRequest;
use Google\ApiCore\ApiException;

function fetchSecret(string $projectId, string $secretId, string $versionId)
{
    if ($projectId != ''){
    // Create the Secret Manager client.
    $client = new SecretManagerServiceClient();

    // Build the resource name of the secret version.
    $name = $client->secretVersionName($projectId, $secretId, $versionId);

    // Build the request.
    $request = AccessSecretVersionRequest::build($name);

    // Access the secret version.
    $response = $client->accessSecretVersion($request);

    // Print the secret payload.
    //
    // WARNING: Do not print the secret in a production environment - this
    // snippet is showing how to access the secret material.
    $payload = $response->getPayload()->getData();
    return $payload;
    }
}

$operation = $_GET['operation'] ?? null;
if ($operation === 'setProductId') {
    $id = htmlentities($_GET['project_id']);
    $_SESSION['gcp_project_id'] = $id;
    echo json_encode(['error' => false]);
}
if($_SESSION['gcp_project_id'] != ''){
    // Fetch DB configurations from secrets
    $gcp_project_id = $_SESSION['gcp_project_id'];
    $read_db_config['db-hostname'] = fetchSecret($gcp_project_id, "db-hostname", "latest");
    $read_db_config['db-username'] = fetchSecret($gcp_project_id, "db-username", "latest");
    $read_db_config['db-password'] = fetchSecret($gcp_project_id, "db-password", "latest");
    $read_db_config['db-schema'] = fetchSecret($gcp_project_id, "db-schema", "latest");
    $read_db_config['db-table'] = fetchSecret($gcp_project_id, "db-table", "latest");

    //replicating since we are using same db to read and write
    $write_db_config = $read_db_config;
    // Connect to databases
    $read_conn = mysqli_connect(
        $read_db_config['db-hostname'],
        $read_db_config['db-username'],
        $read_db_config['db-password'],
        $read_db_config['db-schema']
    );

    if (!$read_conn) {
        die(json_encode(['error' => true, 'message' => 'Read DB connection failed: ' . mysqli_connect_error()]));
    }

    $write_conn = mysqli_connect(
        $write_db_config['db-hostname'],
        $write_db_config['db-username'],
        $write_db_config['db-password'],
        $write_db_config['db-schema']
    );

    if (!$write_conn) {
        die(json_encode(['error' => true, 'message' => 'Write DB connection failed: ' . mysqli_connect_error()]));
    }

    if ($operation === 'get') {
        $sql = 'SELECT * FROM ' . $read_db_config['db-table'];
        $result = $read_conn->query($sql);

        if ($result) {
            $products = [];
            while ($row = mysqli_fetch_assoc($result)) {
                $products[] = $row;
            }
            echo json_encode(['error' => false, 'products' => $products]);
        } else {
            echo json_encode(['error' => true, 'message' => 'Error fetching data: ' . mysqli_error($read_conn)]);
        }
    } elseif ($operation === 'add') {
        $name = htmlentities($_GET['product_name']);
        $quantity = htmlentities($_GET['product_quantity']);
        $price = htmlentities($_GET['product_price']);
        $sql = 'INSERT INTO ' . $write_db_config['db-table'] . " (name, quantity, price) VALUES ('$name', '$quantity', '$price')";

        if ($write_conn->query($sql) === true) {
            echo json_encode(['error' => false, 'message' => 'Data added successfully']);
        } else {
            echo json_encode(['error' => true, 'message' => 'Error adding data: ' . mysqli_error($write_conn)]);
        }
    } elseif ($operation === 'update') {
        $id = htmlentities($_GET['product_id']);
        $name = htmlentities($_GET['product_name']);
        $quantity = htmlentities($_GET['product_quantity']);
        $price = htmlentities($_GET['product_price']);
        $sql = 'UPDATE ' . $write_db_config['db-table'] . " SET name='$name', quantity='$quantity', price='$price' WHERE id='$id'";

        if ($write_conn->query($sql) === true) {
            echo json_encode(['error' => false, 'message' => 'Data updated successfully']);
        } else {
            echo json_encode(['error' => true, 'message' => 'Error updating data: ' . mysqli_error($write_conn)]);
        }
    } elseif ($operation === 'delete') {
        $id = htmlentities($_GET['product_id']);
        $sql = 'DELETE FROM ' . $write_db_config['db-table'] . " WHERE id='$id'";

        if ($write_conn->query($sql) === true) {
            echo json_encode(['error' => false, 'message' => 'Data deleted successfully']);
        } else {
            echo json_encode(['error' => true, 'message' => 'Error deleting data: ' . mysqli_error($write_conn)]);
        }
    }elseif ($operation === 'setProductId') {
        $id = htmlentities($_GET['project_id']);
        $gcp_project_id = $id;
    } else {
        echo json_encode(['error' => true, 'message' => 'Invalid or missing operation']);
    }

    mysqli_close($read_conn);
    mysqli_close($write_conn);

}
